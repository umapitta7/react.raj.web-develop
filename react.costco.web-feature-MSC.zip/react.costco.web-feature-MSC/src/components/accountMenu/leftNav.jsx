/* eslint-disable no-useless-constructor */
/* eslint-disable react/jsx-props-no-spreading */
import React, { PureComponent, Suspense } from 'react';

import './index.css';
import '../../translations/language';
import DrawerContent from './drawerContent';

class LeftNav extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    const { props: { signout, site, store } } = this.props;
    return (
      <div>
        <Suspense fallback="">
          <DrawerContent signout={signout} iconColor={false} site={site} store={store} />
        </Suspense>
      </div>
    );
  }
}

export default LeftNav;
