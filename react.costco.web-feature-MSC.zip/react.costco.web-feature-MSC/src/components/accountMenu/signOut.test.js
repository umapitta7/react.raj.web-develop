import React from "react"
import { render, screen } from "@testing-library/react"

import SignOut from "./signOut"

describe("SignOut", () => {
  const signout = {
    ssoUrls:
      "https://wcs.costco.com,https://wcs.costco.ca,https://www.costco.com,https://www.costco.ca",
    ssoEnabled: true,
    isMobile: false,
  }

  test("renders SignOut component", () => {
    render(<SignOut signout={signout} />)
    screen.getByText("Sign Out")
  })
})
