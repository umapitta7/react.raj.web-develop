export const errorConfig = {
  DeliveryZipCode: {
    1001: 'registerEmailError',
    1002: 'registerPhoneError',
    1004: 'registerLoginExistsError',
    1006: 'customerAlreadyExist',
  },
};
