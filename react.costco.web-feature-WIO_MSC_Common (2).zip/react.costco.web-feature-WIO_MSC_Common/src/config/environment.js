import { Utils } from '../utils';
import { environmentDev } from './environment_dev';
import { environmentProd } from './environment_prod';
import { environmentQA } from './environment_qa';

/* Envionment data will be recieved from WCS through window object */
const envJSON = {
  DEV: environmentDev,
  PROD: environmentProd,
  QA: environmentQA,
};
let env = envJSON[window.reactObj.global.environment];
if (Utils.isEmpty(env)) {
  env = envJSON.PROD;
} else {
  env = envJSON.QA; // Falback to QA - Temp Fix - Fallback will be removed
  console.log('Envrionment not set - Please check window.reactObj.global.environment in Header.jsp. ');
}

console.log('env', env);

export const environment = {
  mockEnabled: env.mockEnabled,
  appId: env.appId,
  api: {
    name: env.name,
    mockurl: env.mockurl,
    endpointUrl: env.api.endpointUrl,
    sameDayDeliveryUrl: env.api.sameDayDeliveryUrl,
    headers: env.headers,
  },
};
