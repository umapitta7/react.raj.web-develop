/* eslint-disable no-useless-constructor */
/* eslint-disable react/jsx-props-no-spreading */
import React, { PureComponent, Suspense } from 'react';
import './index.css';
import '../../translations/language';
import DeliveryLocation from './components/DeliveryLocation';

class Index extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    const { props: { headerInfo } } = this.props;

    return (
      <div>
        <Suspense fallback="">
          <DeliveryLocation headerInfo={headerInfo} />
        </Suspense>
      </div>
    );
  }
}

export default Index;
