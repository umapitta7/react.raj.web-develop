import React from 'react';
import TextField from "@material-ui/core/TextField"
import Button from 'forge-components/dist/components/Button';
import Text from 'forge-components/dist/components/Text';
import XIcon from "forge-components/dist/components/Icon/svg-icons/X.js"
import { Grid, Col, Row } from 'react-styled-flexboxgrid-v2';
import { useTranslation } from 'react-i18next';
import "../index.css";
import PropTypes from 'prop-types';
import useBingUtil from "./useBingUtil";



const SidePanel = ({ onPanelClose, onUpdateDeliveryLocation }) => {

  const [ error, setError ] = React.useState(false);

  const [ zipCode, setZipCode ] = React.useState("");

  const [ errorMessage, setErrorMessage ] = React.useState("");


  const { t } = useTranslation();

  const isUS = wcs.storeId === "10301";



  const codeIsValid = (val) => {
    let isValidZipLength = false;
    // Zip Code validation
    if (isUS) {
      isValidZipLength = /(^\d{5}$)|(^\d{5}-\d{4}$)/.test(val);
    }
    // Postal code validation
    else {
      isValidZipLength = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/.test(val);
    }
    return isValidZipLength;
  };

  const zipValidation = async (val) => {
    const invalidZip = await useBingUtil(val);
    return invalidZip;
  }

  const handleInput = (e) => {
    const zipCode = e.target.value;
    setZipCode(zipCode);
    const isZipCodeValid = codeIsValid(zipCode);
    if(isZipCodeValid) {
      setErrorMode(false);
    } else {
      setErrorMode(true);
    }

  }



  //Set Error status for textbox field.
  const setErrorMode = (status) => {
    if (status) {
      setError(true);
      setErrorMessage(t("noCodeError"));
    } else {
      setError(false);
      setErrorMessage("");
    }
  }


  return (
    <>
      <Grid fluid>
        <Row style={{ display: "flex", alignItems: "center", marginTop: "12px" }}>
          <Col xs={11} sm={11} md={11} lg={11}>
            <Text style={{ fontSize: "18px", color: "#333333" }}>{t("changeDeliveryLocation")}</Text>
          </Col>
          <Col xs={1} sm={1} md={1} lg={1} style={{ display: "flex", justifyContent: "flex-end" }}>
            <span onClick={onPanelClose} style={{ cursor: "pointer", height: "16px" }}><XIcon /></span>
          </Col>
        </Row>
        <Row style={{ marginTop: "4px" }}>
          <Col xs={12} sm={12} md={12} lg={12}>
            <div className={"delivery-location-espot"}><Text >{t("itemAvailability")}</Text> </div>
          </Col>
        </Row>
        <form>
          <Row>
            <Col xs={12} sm={12} md={12} lg={12}>
              <TextField id="zipCode"
                onInput={(e) => {
                  handleInput(e);
                }}
                size="small"
                type={isUS ? "number" : "text"}
                style={{ width: "100%", marginTop: "16px" }}
                variant="outlined"
                label={t("zipCode")}
                error={error}
                helperText={error ? errorMessage : ""}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={12} sm={12} md={12} lg={12}>
              <Button
                type="submit"
                onClick={async (e) => {
                  e.preventDefault();
                  const zipCodeVal = zipCode;
                  const codeLengthValid = codeIsValid(zipCodeVal);
                  if (codeLengthValid) {
                    const zipCodeValid = ! await zipValidation(zipCodeVal);
                    console.log(zipCodeValid);
                    if (zipCodeValid) {
                      onUpdateDeliveryLocation(zipCodeVal);
                      setErrorMode(false);
                      onPanelClose(e);
                    } else {
                      setErrorMode(true);
                    }
                  } else {
                    setErrorMode(true);
                  }
                }
                }
                style={{ width: "100%", marginTop: "12px" }}
              >
                {t("changeDeliveryLocation")}
              </Button>
            </Col>
          </Row>
        </form>
      </Grid>
    </>
  )
}

export default SidePanel;

SidePanel.propTypes = {
  onPanelClose: PropTypes.func.isRequired,
  onUpdateDeliveryLocation: PropTypes.func.isRequired,
};
