import React from "react";
import { Col, Grid, Row } from "react-styled-flexboxgrid-v2";
import DeliveryLocationIcon from "forge-components/dist/components/Icon/svg-icons/BoxSolid.js";
import { useTranslation } from "react-i18next";
import "../index.css";
import MyWarehouseSelection from "../../MyWarehouse/components/myWarehouseSelection";
import PropTypes from 'prop-types';


const Header = ({
  onChangeDeliveryLocation,
  selectedZip,
}) => {
  const { t } = useTranslation()

  return (
    <>
      <Row className={"delivery-location-wrapper"}>
        <Col xs={12} sm={12} lg={12} xl={12}>
          <Row className={"header-spacing"}>
            <MyWarehouseSelection />
            <Grid
              fluid
              className="header-padding"
              style={{
                marginLeft: "unset",
                marginRight: "unset",
                paddingLeft: "50px",
              }}
            >
              <Row>{t("deliveryLocation")}</Row>
              <Row className="header-spacing">
                <DeliveryLocationIcon className={"delivery-location-icon"} />
                {selectedZip ? (
                  <a
                    onClick={onChangeDeliveryLocation}
                    onKeyDown={(e) => e.key === "Enter" ? onChangeDeliveryLocation : ""}
                    className={"header-link"}
                    tabIndex={0}
                  >
                    {selectedZip}
                  </a>
                ) : (
                  <a
                    onClick={onChangeDeliveryLocation}
                    onKeyDown={(e) => {e.key === "Enter" ? onChangeDeliveryLocation : console.log(e.key)}}
                    className={"header-link"}
                    tabIndex={0}
                  >
                    {t("setDeliveryLocation")}
                  </a>
                )}
              </Row>
            </Grid>
          </Row>
        </Col>
      </Row>
    </>
  )
}

export default Header;

Header.propTypes = {
    onChangeDeliveryLocation: PropTypes.func.isRequired,
    selectedZip: PropTypes.number,
  };
  
  Header.defaultProps = {
    selectedZip: '',
  };
