import useBingLocation from "../../../customHooks/useBingLocation";
import { CookieHandler } from "../../../utils/CookieHandler";

const cityKey = "invCheckCity";
const stateKey = "invCheckStateCode";
const isUS = wcs.storeId === "10301";
const isCA = wcs.storeId === "10302";

const useBingUtil = async (zipCode) => { 
   
    const location = await useBingLocation(zipCode); 
    let invalidZip = false; 
    let country;
    let province;      
    if(location){      
      if(location?.address){          
        if(location.address.locality) {          
          let city = location.address.locality;                          
          CookieHandler.set(cityKey, city);
        }
        if(location.address.adminDistrict) {
          province = location.address.adminDistrict;
          CookieHandler.set(stateKey, province);
        }
        if(location.address.countryRegionIso2) {
           country = location.address.countryRegionIso2;
        }         
        if(!location.address.adminDistrict === null && location.address.countryRegionIso2 === 'PR'){
          province = location.address.countryRegionIso2;
          country= 'US';
          CookieHandler.set(stateKey, province);            
        }
        if(!country && !province) {           
          invalidZip = true;
        }         
        if(isUS && country!== 'US'){            
          invalidZip = true;
        }else{            
          if(isCA && country !== 'CA'){             
            invalidZip = true;
          }
        }         

      } else{          
        invalidZip = true;
      }      	
    }else{
      invalidZip = true;
    }            
    return invalidZip;
  };

  export default useBingUtil;

