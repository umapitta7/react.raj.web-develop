import React from 'react';
import '../../translations/language';
import MyWarehouseSelection from './components/myWarehouseSelection';

const MyWarehouse = () => (
  <>
    <MyWarehouseSelection style={{ zIndex: '20012' }} />
  </>
);
export default MyWarehouse;
