/* eslint-disable no-useless-constructor */
import React, { PureComponent, Suspense } from 'react';
import App from './app';
import './index.css';
import '../../translations/language';

// Note I don't set a fallback value for Suspense but we should add something.
class Index extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    // passing site and store props
    const { props: { site, store } } = this.props;

    return (
      <div>
        <Suspense fallback="">
          <App site={site} store={store} />
        </Suspense>
      </div>
    );
  }
}

export default Index;
