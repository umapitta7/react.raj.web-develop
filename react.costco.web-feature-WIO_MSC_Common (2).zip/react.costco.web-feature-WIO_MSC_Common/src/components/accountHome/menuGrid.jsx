import React from "react"
import Grid from "@material-ui/core/Grid"
import styled from "styled-components"
import PropTypes from "prop-types"
import { useTranslation } from "react-i18next"
import {
  digitalMembershipCardUrl,
  bdAccountDetailsUrl,
  bdCommunicationPreferenceUrl,
  myOrdersUrl,
  accountDetailsUrl,
  businessDetailsUrl,
  renewMembershipUrl,
  addressBookUrl,
  paymentMethodsUrl,
  costcoPayurl,
  myListsUrl,
  communicationPreferenceUrl,
} from "../common/myAccount/accountLinks"
import {
  MembershipCard,
  Orders,
  AccountDetails,
  BusinessCenter,
  Renew,
  LocationSpecific,
  PaymentMethods,
  Lists,
  Settings,
  CostcoPay,
} from "forge-components/dist/icons"
import Text from "forge-components/dist/components/Text"
import IconLabel from "../accountMenu/IconLabel"

const bdMenuList = [
  {
    id: 2,
    label: "Orders.label",
    icon: function (t) {
      return (
        <Orders
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "Orders.description",
    link: myOrdersUrl,
  },

  {
    id: 3,
    label: "AccountDetails.label",
    icon: function (t) {
      return (
        <AccountDetails
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "AccountDetails.description",
    link: bdAccountDetailsUrl,
  },
  {
    id: 6,
    label: "LocationSpecific.label",
    icon: function (t) {
      return (
        <LocationSpecific
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "LocationSpecific.description",
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "PaymentMethods.label",
    icon: function (t) {
      return (
        <PaymentMethods
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "PaymentMethods.description",
    link: paymentMethodsUrl,
  },
  {
    id: 9,
    label: "Lists.label",
    icon: function (t) {
      return (
        <Lists key={`grid_${this.id}`} title={t(this.label)} color="red.500" width={60} height={60} />
      )
    },
    description: "Lists.description",
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Settings.label",
    icon: function (t) {
      return (
        <Settings
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "Settings.description",
    link: bdCommunicationPreferenceUrl,
  },
]

const bcMenuList = [
  {
    id: 2,
    label: "Orders.label",
    icon: function (t) {
      return (
        <Orders
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    link: myOrdersUrl,
    description: "Orders.description",
  },
  {
    id: 3,
    label: "AccountDetails.label",
    icon: function (t) {
      return (
        <AccountDetails
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    link: accountDetailsUrl,
    description: "AccountDetails.description",
  },
  {
    // Only for Business member
    id: 4,
    label: "BusinessCenter.label",
    icon: function (t) {
      return (
        <BusinessCenter
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "BusinessCenter.description",
    link: businessDetailsUrl,
  },
  {
    id: 5,
    label: "Renew.label",
    icon: function (t) {
      return (
        <Renew key={`grid_${this.id}`} title={t(this.label)} color="red.500" width={60} height={60} />
      )
    },
    description: "Renew.description",
    link: renewMembershipUrl,
  },
  {
    id: 6,
    label: "LocationSpecific.label",
    icon: function (t) {
      return (
        <LocationSpecific
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "LocationSpecific.description",
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "PaymentMethods.label",
    icon: function (t) {
      return (
        <PaymentMethods
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    link: paymentMethodsUrl,
    description: "PaymentMethods.description",
  },
  {
    // Only for US
    id: 8,
    label: "CostcoPay.label",
    icon: function (t) {
      return (
        <CostcoPay
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "CostcoPay.description",
    link: costcoPayurl,
  },
  {
    id: 9,
    label: "Lists.label",
    icon: function (t) {
      return (
        <Lists key={`grid_${this.id}`} title={t(this.label)} color="red.500" width={60} height={60} />
      )
    },
    description: "Lists.description",
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Settings.label",
    icon: function (t) {
      return (
        <Settings
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "Settings.description",
    link: communicationPreferenceUrl,
  },
  {
    // Only for US
    id: 11,
    label: "MembershipCard.label",
    icon: function (t) {
      return (
        <MembershipCard
          key={`grid_${this.id}`}
          title={t(this.label)}
          color="red.500"
          width={60}
          height={60}
        />
      )
    },
    description: "MembershipCard.description",
    link: digitalMembershipCardUrl,
  },
]

const menuGridConfig = {
  bc: bcMenuList,
  bd: bdMenuList,
}

const StyleAnchor = styled.a`
text-decoration: none;

&:focus, &:hover, &:visited, &:link, &:active {
    text-decoration: none;
}
`

const Styledlabel = styled(Text)`
  font-weight: bold;
  margin-bottom: 12px !important;
  margin-top: 12px !important;
  text-decoration: none;
  color: #333;
`

const StyledGridItem = styled.div`
  width: 304px;
  height: 195px;
  text-align: center;
  border: 1px solid #dbdbdb;
  padding-left: 16px;
  padding-right: 16px;
  padding-bottom: 8px;
  :hover {
    border: 2px solid #909090 !important;
    ${Styledlabel} {
      text-decoration: underline;
    }
  }
`
const StyledGridDescription = styled.div`
  color: #333;
  padding-top: 12px;
  padding-bottom: 16px;
`

const MenuGrid = ({ site, store }) => {
  const { t } = useTranslation()

  return (
    <Grid
      style={{ paddingBottom: 60 }}
      container
      spacing={4}
      alignItems="stretch"
    >
      {menuGridConfig[site].map(
        product =>
          // hide costco pay and digital membership card for BC CA
          !(
            site === "bc" &&
            store === "ca" &&
            (product.id === 8 || product.id === 11)
          ) && (
            <>
              <Grid
                key={`grid_${product.id}`}
                item
                direction="column"
                lg={3}
                md={4}
                sm={12}
                xs={12}
                style={{ cursor: "pointer" }}
                
              >
                <StyleAnchor href={product.link}>
                <StyledGridItem tabIndex="1">
                  <Styledlabel variant="t5">{t(product.label)}</Styledlabel>

                  {product.icon(t)}

                  <StyledGridDescription>
                    <Text variant="t6">{t(product.description)}</Text>
                  </StyledGridDescription>
                </StyledGridItem>
                </StyleAnchor>
              </Grid>
            </>
          )
      )}
    </Grid>
  )
}

MenuGrid.propTypes = {
  site: PropTypes.oneOf(["bd", "bc"]),
  store: PropTypes.string,
}

MenuGrid.defaultProps = { site: "bc", store: "us" }

export default MenuGrid
