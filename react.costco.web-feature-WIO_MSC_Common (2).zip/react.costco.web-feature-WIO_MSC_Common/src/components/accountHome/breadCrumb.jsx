import styled from 'styled-components';
import Text from 'forge-components/dist/components/Text';
import Breadcrumbs from 'forge-components/dist/components/Breadcrumbs';
import { useTranslation } from 'react-i18next';
import { accountHomeUrl } from '../common/myAccount/accountLinks';

const StyledBreadcrumbs = styled.div`
  padding-top: 24px;
  margin: 5px;
`;

const StyleAnchor = styled.a`
  color: #000000 !important;
  text-decoration: none !important;
`;

const StyledText = styled(Text)`
  padding-top: 24px;
  padding-bottom: 16px;
`;

const Breadcrumb = () => {
  const { t } = useTranslation();
  return (
    <StyledBreadcrumbs>
      <Breadcrumbs separator="/">
        <StyleAnchor href="/">{t('Home')}</StyleAnchor>
        <StyleAnchor href={accountHomeUrl}>{t('Account Home')}</StyleAnchor>
      </Breadcrumbs>
      <StyledText variant="t1">{t('Account Home')}</StyledText>
    </StyledBreadcrumbs>
  );
};

export default Breadcrumb;
