import React from "react"
import PropTypes from "prop-types"
import { useTranslation } from "react-i18next"
import Typography from "@material-ui/core/Typography"
import { Row, Col } from "react-styled-flexboxgrid-v2"
import styled from "styled-components"
import Text from "forge-components/dist/components/Text"
import CdsButton from "forge-components/dist/components/Button/"
// import useSkeletonGenerator from "../../customHooks/useSkeletonGenerator"
import WarehouseReceiptModal from "../../components/modal/warehouseReceiptModal"

const StyledButton = styled(CdsButton)`
  height: 40px;
  width: 256px !important;
  border-radius: 3px;
  color: #ffffff;
  background-color: #3071a9;
  float: right;
`

const WarehousePurchase = ({ style }) => {
  const { t } = useTranslation()

  const [open, setOpen] = React.useState(false)
  const handleClickOpen = () => {
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const queryToMatch = '(min-width: 768px)';
  const [matches, setMatches] = React.useState(window.matchMedia(queryToMatch).matches);
  const [ buttonColPadding, setButtonColPadding ] = React.useState('16px 16px 16px 16px');

  React.useEffect(() => {
    const media = window.matchMedia(queryToMatch);
    const listener = () => { 
        setMatches(media.matches);
    };

    media.addEventListener('change', listener);

    return () => media.removeEventListener('change', listener);
  }, []);

  React.useEffect(() => {
    if (matches) {
      setButtonColPadding('16px 16px 16px 16px');
    } else {
      setButtonColPadding('0px 16px 16px 16px');
    }

  },[matches]);

  return (
    <Row
      style={{
        border: "1px solid #dbdbdb",
        margin: "0",
      }}
    >
      <Col
        xs={12}
        sm={7}
        md={7}
        lg={7}
        style={{
          // border: "1px solid #dbdbdb",
          padding: "16px",
        }}
      >
        <Text variant="t4" style={{ fontWeight: "bold" }}>
          {t("In-Warehouse")}
        </Text>
        <Text variant="t5">01/172021 - 12:10pm</Text>
        <Text variant="t5" style={{ fontWeight: "bold", paddingTop: "4px" }}>
          Warehouse Name
        </Text>
        <Text
          as="span"
          variant="t5"
          style={{ fontWeight: "bold", paddingTop: "4px" }}
        >
          {t("Total")}
        </Text>{" "}
        <Text as="span" variant="t5" syle={{ paddingTop: "4px" }}>
          $58.23
        </Text>
      </Col>

      <Col
        xs={12}
        sm={5}
        md={5}
        lg={5}
        style={{
          // border: "1px solid #dbdbdb",
          padding: buttonColPadding,
          float: "right",
        }}
      >
        <StyledButton
          onClick={() => handleClickOpen()}
          variant="primary-outline"
        >
          <Typography>{t("View Receipt")}</Typography>
        </StyledButton>

        <WarehouseReceiptModal
          open={open}
          onClose={handleClose}
          style={{ zIndex: "20012" }}
        />
      </Col>
    </Row>
  )
}

export default WarehousePurchase

WarehousePurchase.propTypes = {
  // warehouse: PropTypes.shape({}).isRequired,
  displayReceipt: PropTypes.func,
}

WarehousePurchase.defaultProps = {}
