import React from "react";
import agent from "../utils/agent";

import { CookieHandler } from "../utils/CookieHandler";

// TODO: Move constants to environment config file
const wcsCookie = "WAREHOUSEDELIVERY_WHS";
const akamaiCookie = "client-zip-short";
// Fallback location is Issaquah.  The companies HQ.
const latitude = 47.564661;
const longitude = -122.32941;

const fallbackLocation = {
  latitude,
  longitude,
};

/**
 * Converts zipCode to lat and lng using service call to Bing.
 * @param {} q 
 * @returns { latitude, latitude }
 */
const getAddressLocation = async (q) => {
  const results = await agent.getLocation(q); // Service call is cached for a 24hours
  const { resources } = results.resourceSets[0];
  const resource = resources.find((element) => element.confidence === "High");
  return {
    latitude: resource.point.coordinates[0],
    longitude: resource.point.coordinates[1],
  };
};

/**
 * Custom React Hook
 * @returns { latitude, latitude } location
 */
const useLocation = () => {
  let location = fallbackLocation;
  let postalCode;

  // Check WebSphere's cookie first
  if (CookieHandler.cookieExists(wcsCookie)) {
    let cookie = CookieHandler.get(wcsCookie);
    if (cookie.storeLocation) {
      postalCode = cookie.storeLocation;
    } else {
      cookie = CookieHandler.get(akamaiCookie);
      if (cookie) {
        postalCode = cookie;
      }
    }
  } else {
    // Check Akamai's cookie
    const cookie = CookieHandler.get(akamaiCookie);
    if (cookie) {
      postalCode = cookie;
    }
  }

  React.useEffect(() => {
    const getLocation = async (postalCode) => {
      if (postalCode) {
        location = await getAddressLocation(postalCode);
      }
    };

    // Use postal code from WebSphere or Akamai to get the lat and lng coordinates
    getLocation(postalCode);
  }, [postalCode]);

  return location;
};

export default useLocation;
