import agent from '../utils/agent';

/**
 * Converts zipCode to lat and lng using service call to Bing.
 * @param {} q
 * @returns { latitude, latitude }
 */
const getAddressOfZip = async (q) => {
  const results = await agent.getLocationWithNeighborhood(q);
  if (results) {
    if (results.resourceSets[0]) {
      const { resources } = results.resourceSets[0];
      const resource = resources.find((element) => element.confidence === 'High');
      if (resource?.address) {
        return {
          latitude: resource.point.coordinates[0],
          longitude: resource.point.coordinates[1],
          address: resource.address
        };
      }
    }
  }
  return undefined;
};

const useBingLocation = async (postalCode) => {
  let location;
  if (postalCode !== 0) {
    location = await getAddressOfZip(postalCode);
  }
  return location;
};

export default useBingLocation;
