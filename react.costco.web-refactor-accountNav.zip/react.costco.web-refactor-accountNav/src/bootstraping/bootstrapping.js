import React from 'react';

export function siblingComponentList() {
  return {
    accountMenu: React.lazy(() => import('../components/accountMenu')),
    accountHome: React.lazy(() => import('../components/accountHome')),
    leftNavA: React.lazy(() => import('../components/accountMenu/leftNavA')),
    leftNavB: React.lazy(() => import('../components/accountMenu/leftNavB')),
    orders: React.lazy(() => import('../components/orders')),

    warehouseSidebar: React.lazy(() => import('../components/WarehouseSidebar')),
    fulfillments: React.lazy(() => import('../components/Fulfillments/Fulfillments')),
    deliveryLocation: React.lazy(() => import('../components/DeliveryLocation/DeliveryLocation')),
    myWarehouse: React.lazy(() => import('../components/MyWarehouse/myWarehouse'))
  };
}
