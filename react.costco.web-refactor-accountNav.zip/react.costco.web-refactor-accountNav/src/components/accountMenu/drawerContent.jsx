import { Divider } from '@material-ui/core';
import styled from 'styled-components';
import { Box } from 'reflexbox';
import PropTypes from 'prop-types';
import React from 'react';
import '../../translations/language';
import './index.css';
import UserInfo from './userInfo';
import MenuList from './menuList';
import { SignOutShape } from '../common/propTypes';

const StyledBox = styled(Box)`
  width: 320px;
  height: 100%;
  list-style-position: inside;
`;

const DrawerContent = ({
  signout,
  showDivider,
  onClose,
  site,
  store,
}) => (
  <StyledBox>
    <UserInfo onClose={onClose} />
    <Divider />
    <div style={{ paddingBottom: 8 }}>
      <MenuList
        site={site}
        store={store}
        signout={signout}
        showDivider={showDivider}
      />
    </div>
  </StyledBox>
);

DrawerContent.propTypes = {
  onClose: PropTypes.func,
  showDivider: PropTypes.bool,
  signout: PropTypes.shape(SignOutShape).isRequired,
  site: PropTypes.string.isRequired,
  store: PropTypes.string.isRequired,
};

DrawerContent.defaultProps = {
  onClose: null,
  showDivider: false,
};

export default DrawerContent;
