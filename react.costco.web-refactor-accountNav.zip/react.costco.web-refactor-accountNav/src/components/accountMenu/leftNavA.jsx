/* eslint-disable no-useless-constructor */
/* eslint-disable react/jsx-props-no-spreading */
import React, { PureComponent, Suspense } from 'react';

import './index.css';
import '../../translations/language';
import LeftNavContent from './leftNavAContent';

class LeftNavA extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    const {
      props: {
        signout, site, store
      },
    } = this.props;

    return (
      <Suspense fallback="">
        <LeftNavContent signout={signout} site={site} store={store} showDivider />
      </Suspense>
    );
  }
}

export default LeftNavA;
