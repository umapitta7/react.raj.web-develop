import { Divider } from '@material-ui/core';
import { Grid, Col } from 'react-styled-flexboxgrid-v2';
import PropTypes from 'prop-types';
import React from 'react';
import '../../translations/language';
import './index.css';
import { ThemeContext } from 'styled-components';
import UserInfo from './userInfo';
import MenuList from './menuList';
import { SignOutShape } from '../common/propTypes';

const queryToMatch = '(min-width: 1025px)';

const LeftNavContent = ({
  signout, showDivider, onClose, site, store
}) => {
  const themeContext = React.useContext(ThemeContext);
  const [screenSizeMatches, setScreenSizeMatches] = React.useState(
    window.matchMedia(queryToMatch).matches
  );

  // We don't display this grid on a tablet or smaller device according to the specs.
  React.useEffect(() => {
    const media = window.matchMedia(queryToMatch);
    const listener = () => {
      setScreenSizeMatches(media.matches);
    };

    media.addEventListener('change', listener);

    return () => media.removeEventListener('change', listener);
  }, []);

  if (!screenSizeMatches) {
    return (
      <Grid
        xs={12}
        sm={12}
        md={12}
        style={{
          padding: '0px',
          float: 'left',
          paddingBottom: 8,
        }}
      >
        <Col style={{ padding: '0px' }}>
          <UserInfo onClose={onClose} />
          <Divider />
          <MenuList
            site={site}
            store={store}
            signout={signout}
            iconColor={themeContext.colors.red[500]}
            showDivider={showDivider}
          />
        </Col>
      </Grid>
    );
  }
  return null;
};

LeftNavContent.propTypes = {
  onClose: PropTypes.func,
  showDivider: PropTypes.bool,
  signout: PropTypes.shape(SignOutShape).isRequired,
  site: PropTypes.string.isRequired,
  store: PropTypes.string.isRequired,
};

LeftNavContent.defaultProps = {
  onClose: null,
  showDivider: false,
};

export default LeftNavContent;
