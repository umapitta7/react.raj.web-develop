import React from "react"
import { Divider } from "@material-ui/core"
import PropTypes from "prop-types"
import {
  digitalMembershipCardUrl,
  bdAccountDetailsUrl,
  bdCommunicationPreferenceUrl,
  accountHomeUrl,
  myOrdersUrl,
  accountDetailsUrl,
  businessDetailsUrl,
  renewMembershipUrl,
  addressBookUrl,
  paymentMethodsUrl,
  costcoPayurl,
  myListsUrl,
  communicationPreferenceUrl,
} from "../common/myAccount/accountLinks"
import {
  MembershipCard,
  Account,
  Orders,
  AccountDetails,
  BusinessCenter,
  Renew,
  LocationSpecific,
  PaymentMethods,
  Lists,
  Settings,
  CostcoPay,
  SignOut,
} from "forge-components/dist/icons"
import Text from "forge-components/dist/components/Text"
import { ThemeContext } from 'styled-components';
import AccountNavList from "forge-components/dist/components/Surfaces/AccountNavList"
import { SignOutShape } from "../common/propTypes"
import { ListItem } from "forge-components/dist/components/List"
import { useTranslation } from "react-i18next"
import styled from "styled-components"

const bdMenuList = [
  {
    id: 1,
    label: "Account Home",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Account
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: accountHomeUrl,
  },
  {
    id: 2,
    label: "Orders & Purchases",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Orders
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myOrdersUrl,
  },
  {
    id: 3,
    label: "Account Details",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <AccountDetails
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: bdAccountDetailsUrl,
  },
  {
    id: 6,
    label: "Address Book",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <LocationSpecific
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "Payment Methods",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <PaymentMethods
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: paymentMethodsUrl,
  },
  {
    id: 9,
    label: "Lists",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Lists
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Preferences",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Settings
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: bdCommunicationPreferenceUrl,
  },
]

const bcMenuList = [
  {
    id: 1,
    label: "Account Home",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Account
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: accountHomeUrl,
  },
  {
    id: 2,
    label: "Orders & Purchases",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Orders
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myOrdersUrl,
  },
  {
    id: 3,
    label: "Account Details",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <AccountDetails
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: accountDetailsUrl,
  },
  {
    // verified Business members only
    id: 4,
    label: "Business Details",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <BusinessCenter
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: businessDetailsUrl,
  },
  {
    id: 5,
    label: "Renew Membership",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Renew
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: renewMembershipUrl,
  },
  {
    id: 6,
    label: "Address Book",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <LocationSpecific
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "Payment Methods",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <PaymentMethods
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: paymentMethodsUrl,
  },
  {
    // Only for US
    id: 8,
    label: "Costco Pay",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <CostcoPay
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: costcoPayurl,
  },
  {
    id: 9,
    label: "Lists",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Lists
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Preferences",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Settings
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: communicationPreferenceUrl,
  },
  {
    // Only for US
    id: 11,
    label: "Digital Membership Card",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <MembershipCard
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: digitalMembershipCardUrl,
  },
]

const nonMemberMenuList = [
  {
    id: 1,
    label: "Account Home",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Account
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: accountHomeUrl,
  },
  {
    id: 2,
    label: "Orders & Purchases",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Orders
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myOrdersUrl,
  },
  {
    id: 3,
    label: "Account Details",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <AccountDetails
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: accountDetailsUrl,
  },
  {
    // BC Only
    id: 5,
    label: "Renew Membership",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Renew
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: renewMembershipUrl,
  },
  {
    id: 6,
    label: "Address Book",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <LocationSpecific
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "Payment Methods",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <PaymentMethods
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: paymentMethodsUrl,
  },
  {
    // Only for  BC US
    id: 8,
    label: "Costco Pay",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <CostcoPay
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: costcoPayurl,
  },
  {
    id: 9,
    label: "Lists",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Lists
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Preferences",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <Settings
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: communicationPreferenceUrl,
  },
  {
    // Only for BC US
    id: 11,
    label: "Digital Membership Card",
    icon: function (id, title, iconColor, iconWidth, iconHeight) {
      return (
        <MembershipCard
          key={id}
          title={title}
          color={iconColor}
          width={iconWidth}
          height={iconHeight}
        />
      )
    },
    link: digitalMembershipCardUrl,
  },
]

const menuItemsConfig = {
  bc: bcMenuList,
  bd: bdMenuList,
  non_member: nonMemberMenuList,
}

const StyledListItem = styled(ListItem)`
  span:hover {
    font-weight: ${props => props.theme.fontWeights.bold};
  }
  border-top-right-radius: 12px;
  border-bottom-right-radius: 12px;
  padding-left: 16px;
  padding-top: 12px;
  padding-bottom: 12px;
`

const MenuList = ({
  site,
  store,
  iconColor,
  iconWidth,
  iconHeight,
  showDivider,
  signout,
}) => {
  const themeContext = React.useContext(ThemeContext);
  const { t } = useTranslation()
  const [selectedMenuItem, setSelectedMenuItem] = React.useState(
    window.sessionStorage.getItem("selectedMenuItem")
  )

  // Filter menu items
  const filteredMenuItems = menuItemsConfig[site].filter(
    item =>
      !(
        site !== "bd" &&
        store === "ca" &&
        (item.label === "Costco Pay" ||
          item.label === "Digital Membership Card")
      )
  )

  // Generate menuItem jsx content from menuItems
  const menuItems = filteredMenuItems.map(item => {
    const { id, label, icon, link } = item
    const translatedLabel = t(label)
    return (
      <>
        <StyledListItem
          id={id}
          key={`ListItem_${id}`}
          tabIndex="0"
          {...(label === selectedMenuItem && {
            style: {
              borderLeft: "solid 5px",
              borderLeftColor: "#005dab",
              backgroundColor: "#eff7fb",
            },
          })}
        >
          <a
            href="javascript:void(0)"
            key={`a_${id}`}
            onClick={() => {
              window.sessionStorage.setItem("selectedMenuItem", label)
              setSelectedMenuItem(label)
              window.location = link
              return false
            }}
            style={{ textDecoration: "none", color: themeContext.colors.text.default }}
          >
            {icon(id, translatedLabel, iconColor, iconWidth, iconHeight)}
            <Text as="span" key={`Text_${id}`} variant="t6" paddingLeft="xs">
              {translatedLabel}
            </Text>
          </a>
        </StyledListItem>
        {showDivider && <Divider key={`Divider_${id}`} />}
      </>
    )
  })

  // If we have a valid signout object, Append signout menuItem
  if (signout && signout.ssoUrls) {
    menuItems.push(
      <>
        <Divider key={`signout_divider_1`} />
        <StyledListItem id="signout" key="signout_1" tabIndex="0">
          <a
            href="javascript:void(0)"
            key="signout_a_1"
            onClick={() =>
              window.COSTCO.util.logoutSso(
                null,
                signout.ssoUrls,
                signout.ssoEnabled,
                signout.isMobile
              )
            }
            style={{ textDecoration: "none", color: themeContext.colors.text.default }}
          >
            <SignOut
              key="signout_icon_1"
              title="signout"
              color={iconColor}
              width={iconWidth}
              height={iconHeight}
            />
            <Text as="span" key="signout_Text_1" variant="t6" paddingLeft="xs">
              {t("Sign Out")}
            </Text>
          </a>
        </StyledListItem>
      </>
    )
  }

  return <AccountNavList menuItems={menuItems} />
}

MenuList.propTypes = {
  site: PropTypes.oneOf(["bd", "bc", "non_member"]),
  store: PropTypes.string,
  iconColor: PropTypes.string,
  iconWidth: PropTypes.string,
  iconHeight: PropTypes.string,
  showDivider: PropTypes.bool,
  signout: PropTypes.shape(SignOutShape),
}

MenuList.defaultProps = {
  site: "non_member",
  iconColor: "#5f5f5f",
  iconWidth: "22px",
  iconHeight: "22px",
  showDivider: false,
  signout: {},
}

export default MenuList
