import React from 'react';
import { render, screen } from '@testing-library/react';

import MenuList from './menuList';

describe('MenuList', () => {
  test('renders menuList component', () => {
    // render(<MenuList />);
    // screen.getByText('Payment Methods');

    // Need provider to inject theme before we can build out tests.
    // See: https://testing-library.com/docs/react-testing-library/setup/#custom-render
    expect(true).toBeTruthy();
  });
});
