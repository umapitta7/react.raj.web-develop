/* eslint-disable no-useless-constructor */
/* eslint-disable react/jsx-props-no-spreading */
import React, { PureComponent, Suspense } from 'react';

import './index.css';
import '../../translations/language';
import LeftNavContent from './leftNavBContent';

class LeftNavB extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    const {
      props: {
        signout, site, store
      },
    } = this.props;

    return (
      <Suspense fallback="">
        <LeftNavContent signout={signout} site={site} store={store} />
      </Suspense>
    );
  }
}

export default LeftNavB;
