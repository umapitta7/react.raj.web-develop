import { Divider } from '@material-ui/core';
import styled from 'styled-components';
import { Box } from 'reflexbox';
import PropTypes from 'prop-types';
import React from 'react';
import '../../translations/language';
import './index.css';
import UserInfo from './userInfo';
import MenuList from './menuList';
import { SignOutShape } from '../common/propTypes';

const StyledBox = styled(Box)`
  width: 320px;
  height: 100%;
  list-style-position: inside;
`;

const queryToMatch = '(min-width: 1025px)';

const LeftNavContent = ({
  signout, showDivider, onClose, site, store
}) => {
  const [screenSizeMatches, setScreenSizeMatches] = React.useState(
    window.matchMedia(queryToMatch).matches
  );

  // We don't display this grid on a tablet or smaller device according to the specs.
  React.useEffect(() => {
    const media = window.matchMedia(queryToMatch);
    const listener = () => {
      setScreenSizeMatches(media.matches);
    };

    media.addEventListener('change', listener);

    return () => media.removeEventListener('change', listener);
  }, []);

  if (screenSizeMatches) {
    return (
      <StyledBox style={{ paddingBottom: 8 }}>
        <UserInfo onClose={onClose} />
        <Divider />
        <MenuList
          site={site}
          store={store}
          signout={signout}
          showDivider={showDivider}
        />
      </StyledBox>
    );
  }
  return null;
};

LeftNavContent.propTypes = {
  onClose: PropTypes.func,
  showDivider: PropTypes.bool,
  signout: PropTypes.shape(SignOutShape).isRequired,
  site: PropTypes.string.isRequired,
  store: PropTypes.string.isRequired,
};

LeftNavContent.defaultProps = {
  onClose: null,
  showDivider: false,
};

export default LeftNavContent;
