import React from 'react';

const Test = () => <div>Bootstraping test!</div>;

export default Test;
