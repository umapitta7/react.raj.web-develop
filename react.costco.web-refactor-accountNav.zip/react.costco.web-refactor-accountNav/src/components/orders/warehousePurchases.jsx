import React, { lazy, Suspense } from "react"
import { useTranslation } from "react-i18next"
import { Grid, Row as FlexBoxGridRow, Col } from "react-styled-flexboxgrid-v2"
import Text from "forge-components/dist/components/Text"
import { makeStyles } from "@material-ui/core/styles"
import Pagination from "@material-ui/lab/Pagination"
import useSkeletonGenerator from "../../customHooks/useSkeletonGenerator"
// Lazy load these components.
const WarehousePurchase = lazy(() => import("./warehousePurchase"))

const useStyles = makeStyles({
  divChangeLink: {
    hover: "true",
    cursor: "pointer",
  },
  spanChangeLink: {
    color: "#3071a9",
    textDecorationLine: "underline",
    hover: "true",
    cursor: "pointer",
  },
  table: {
    maxWidth: 724,
    minWidth: 228,
  },
  tableCell: {
    '&[class*="MuiTableCell-root"]': {
      padding: "0 !important",
      paddingBottom: "23px !important",
    },
  },
})

const numOfRowsPerPage = parseInt(process.env.REACT_APP_ROWS_PER_PAGE, 10)

const WarehousePurchases = () => {
  const { t } = useTranslation()
  const classes = useStyles()
  const [page, setPage] = React.useState(0)
  const [rowsPerPage, setRowsPerPage] = React.useState(numOfRowsPerPage)

  // const emptyRows =
  //  rowsPerPage - Math.min(rowsPerPage, rows.length - page * rowsPerPage)

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, numOfRowsPerPage))
    setPage(0)
  }

  const Row = ({ index, style }) => {
    return (
      <Suspense
        fallback={useSkeletonGenerator({
          variant: "rect",
          animation: "wave",
          width: "100%",
          height: "auto",
        })}
      >
        <WarehousePurchase />
      </Suspense>
    )
  }

  // Create some dummy records for the table
  const rows = new Array(6).fill({}).reduce((accumulator, value, index) => {
    accumulator[index] = Row(index)
    return accumulator
  }, [])

  return (
    <Grid
      style={{
        padding: "0px",
        float: "left",
      }}
    >
      <FlexBoxGridRow
        style={{ maxWidth: "1036px", margin: "0px" }}
        aria-label="in-warehouse purchases"
      >
        {(rowsPerPage > 0
          ? rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
          : rows
        ).map((row, i) => (
          <Col
            style={{ padding: "0px" }}
            xs={12}
            sm={12}
            md={12}
            lg={12}
            key={i}
          >
            {row}
          </Col>
        ))}

        {/* TODO: Not sure we actually need this.
            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={1} />
              </TableRow>
            )}
            */}
      </FlexBoxGridRow>
      <FlexBoxGridRow
        style={{
          padding: "16px",
          minWidth: "100%",
          margin: "0px",
          borderTop: "solid thin #909090",
          borderBottom: "solid thin #909090",
        }}
      >
        <Col
          xs={12}
          sm={11}
          md={11}
          lg={11}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <Pagination count={10} color="white" variant="outlined" shape="rounded" />
        </Col>
        <Col
          xs={12}
          sm={1}
          md={1}
          lg={1}
          style={{ paddingRight: "0px", display: "flex", alignItems: "center", justifyContent: "flex-end" }}
        >
          <Text
            variant="t6" color="#3071a9"
          >
            Back to Top
          </Text>
        </Col>
      </FlexBoxGridRow>
    </Grid>
  )
}

export default WarehousePurchases
