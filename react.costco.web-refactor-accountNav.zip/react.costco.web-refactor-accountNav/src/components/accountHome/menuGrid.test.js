import React from 'react';
import { render, screen } from '@testing-library/react';

import MenuGrid from './menuGrid';

describe('MenuGrid', () => {
  test('renders MenuItem component', () => {
    render(<MenuGrid />);
    // Jest is mocked to return the key for translations in setupTests.js
    // screen.getByText('Orders.description');

    // Need provider to inject theme before we can build out tests.
    // See: https://testing-library.com/docs/react-testing-library/setup/#custom-render
    expect(true).toBeTruthy();
  });
});
