import React, { lazy } from 'react';

const BreadCrumb = lazy(() => import('./breadCrumb'));
const MenuGrid = lazy(() => import('./menuGrid'));

const queryToMatch = '(min-width: 1025px)';

const AccountHome = (props) => {
  const { site, store } = props;
  const [screenSizeMatches, setScreenSizeMatches] = React.useState(
    window.matchMedia(queryToMatch).matches
  );

  // We don't display this grid on a tablet or smaller device according to the specs.
  React.useEffect(() => {
    const media = window.matchMedia(queryToMatch);
    const listener = () => {
      setScreenSizeMatches(media.matches);
    };

    media.addEventListener('change', listener);

    return () => media.removeEventListener('change', listener);
  }, []);

  if (screenSizeMatches) {
    return (
      <div style={{ marginRight: 50 }}>
        <BreadCrumb />
        <MenuGrid
          site={site}
          store={store}
        />
      </div>
    );
  }
  return null;
};

export default AccountHome;
