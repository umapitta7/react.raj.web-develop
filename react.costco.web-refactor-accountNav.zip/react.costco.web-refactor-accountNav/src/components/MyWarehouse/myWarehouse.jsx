import React from 'react';
import '../../translations/language';
import MyWarehouseSelection from './components/myWarehouseSelection';

const MyWarehouse = () => (
  <>
    <MyWarehouseSelection />
  </>
);
export default MyWarehouse;
