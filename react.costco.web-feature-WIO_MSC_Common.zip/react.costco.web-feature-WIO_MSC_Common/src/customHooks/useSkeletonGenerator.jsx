import Skeleton from '@material-ui/lab/Skeleton';
import React from 'react';

/**
 * Custom React Hook
 * @param {*} param0 
 * @returns 
 */
const useSkeletonGenerator = ({
  variant, animation, width, height
}) => (
  // Returns a MUI skeleton
  <Skeleton
    data-testid="skeleton"
    {...(variant && { variant })}
    {...(animation && { animation })}
    {...(width && { width })}
    {...(height && { height })}
  />
);

export default useSkeletonGenerator
