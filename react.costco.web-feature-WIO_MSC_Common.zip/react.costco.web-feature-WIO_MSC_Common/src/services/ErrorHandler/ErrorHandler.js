import { getTranslateConfig } from '../../translations/language';

export const ErrorHandler = (operationName, errorCode) => {};
