import React from 'react';
import Drawer from '@material-ui/core/Drawer';
import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import Sidebar from './sideBar';

const styles = {
  list: {
    width: 320,
  },
  fullList: {
    width: 'auto',
  },
  paper: {
    // overflow: 'hidden',
    height: 0,
    top: 0
  },
  drawer: {
    '& .MuiBackdrop-root': {
      top: 0
    },
  }
};

const useStyles = makeStyles(styles);

const App = ({ headerInfo }) => {
  // Dynamically modify style based on headerInfo props
  styles.paper.height = `calc(100% - ${headerInfo.height}px)`;
  styles.paper.top = `${headerInfo.height}px`;
  styles.drawer['& .MuiBackdrop-root'].top = `${headerInfo.height}px`;

  const classes = useStyles();

  const [state, setState] = React.useState({
    left: false,
  });

  React.useEffect(() => {
    // Listen for changes on the event bus
    const subscriptionRef = window.wioEventBus.subscribe('openWarehouseSideBar', () => {
      setState((prevState) => ({
        ...prevState,
        left: true,
      }));
    });

    return () => {
      // Clean up code
      if (subscriptionRef && typeof subscriptionRef.unsubscribe === 'function') {
        subscriptionRef.unsubscribe();
      }
    };
  }, []);

  /**
   * Open or close the MUI Drawer so is visible
   * @param  {} anchor
   * @param  {} open
   */
  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event.type === 'keydown'
      && (event.key === 'Tab' || event.key === 'Shift')
    ) {
      return;
    }
    // window.wioEventBus.publish('openWarehouseSideBar');
    setState({ ...state, [anchor]: open });
  };

  /**
   * The Drawer content
   * @param  {} anchor
   */
  const drawerContent = (anchor) => (
    <div
      style={{
        float: 'left',
      }}
      className={clsx(classes.list, {
        [classes.fullList]: anchor === 'top' || anchor === 'bottom',
      })}
      role="presentation"
    >
      <Sidebar setState={setState} />
    </div>
  );

  return (
    <>
      {['left'].map((anchor) => (
        <React.Fragment key={anchor}>
          <Drawer
            anchor={anchor}
            className={classes.drawer}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            classes={{ paper: classes.paper }}
            style={{ zIndex: '0' }} // Interferes with drop down display autosuggest results
          >
            {drawerContent(anchor)}
          </Drawer>
        </React.Fragment>
      ))}
    </>
  );
};

export default App;
