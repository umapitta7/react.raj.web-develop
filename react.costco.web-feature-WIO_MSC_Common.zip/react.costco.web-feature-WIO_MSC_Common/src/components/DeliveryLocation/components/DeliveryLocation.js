import React from "react";
import '../../../translations/language';
import Drawer from "@material-ui/core/Drawer";
import { sessionStorage } from "reactive-localstorage";
import axios from "axios";
import SidePanel from "./SidePanel";
import Header from "./Header";
import { MuiThemeProvider } from "@material-ui/core/styles";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { invokeRESTApi, RestService } from "../../../services/Gateway/restService";
import { CookieHandler } from "../../../utils/CookieHandler";
import { getInLocal } from '../../../utils/storage';
import '../../../translations/language';
import {
  MuiCostcoTheme,
  StyledCostcoTheme,
} from "forge-components/dist/global/CostcoTheme";
import { ThemeProvider as StyledThemeProvider } from "styled-components";
import agent from "../../../utils/agent";

const locale = getInLocal('i18nextLng') || 'en-US';
const storageKey = "WAREHOUSEDELIVERY_WHS";
const zipCodeKey = "invCheckPostalCode";

const styles = {
  list: {
    width: 320,
  },
  fullList: {
    width: "auto",
  },
  paper: {
    // overflow: 'hidden',
    height: 0,
    top: 0
  },
  drawer: {
    '& .MuiBackdrop-root': {
      top: 0
    },
  }
  
};

const useStyles = makeStyles(styles);


export const updateCookieWithLocationCatalog = (locationCatalogData) => {
  let cookie;
  if (CookieHandler.cookieExists(storageKey)) {
    cookie = CookieHandler.get(storageKey);
    cookie.distributionCenters = locationCatalogData.distributionCenters;
    cookie.groceryCenters = locationCatalogData.groceryCenters;
  } else {
    cookie = locationCatalogData;
  }
  CookieHandler.set(storageKey, JSON.stringify(cookie));
  window.location.reload();
};

const DeliveryLocation = ( { headerInfo } ) => {
  // Dynamically modify style based on headerInfo props
  styles.paper.height = `calc(100% - ${headerInfo.height}px)`;
  styles.paper.top = `${headerInfo.height}px`;
  styles.drawer['& .MuiBackdrop-root'].top = `${headerInfo.height}px`;

  const classes = useStyles();

  const [deliveryLocation, setDeliveryLocation] = React.useState({
    shipToLocation: 0,
  });

  const [state, setState] = React.useState({
    left: false,
  });

  // If user already has a selected zipCode, update the state 
  const setZip = () => {
    if (CookieHandler.cookieExists(zipCodeKey)) {
      const selectedZip = CookieHandler.get(zipCodeKey);
      setDeliveryLocation({
        shipToLocation: selectedZip,
      });
    }
    else {
      CookieHandler.set(zipCodeKey, "");
    }
  }

  const changeDeliveryLocation = (newZip) => {
    setDeliveryLocation(() => {
      let cookie;
      if (CookieHandler.cookieExists(storageKey)) {
        cookie = CookieHandler.get(storageKey);
        cookie.shipToLocation = newZip;
      } else {
        cookie = {
          shipToLocation: newZip,
        };
      }
      CookieHandler.set(storageKey, JSON.stringify(cookie));
      CookieHandler.set(zipCodeKey, newZip);
    });
    setDeliveryLocation({
      shipToLocation: newZip,
    });
    agent.getLocationCatalog(newZip).then((response) => {
      updateCookieWithLocationCatalog(response);
    });
    //window.location.reload();
  };

  // CookieHandler.set("selectedLanguage", JSON.stringify("-25"));


  React.useEffect(() => {
    const fn = (key, value) => {
      if (key === "deliveryLocation") {
        setState((prevState) => ({
          ...prevState,
          left: value === "true",
        }));
      }
    };

    // Listen for changes
    sessionStorage.on("change", fn);

    setZip();
    return () => {
      // Clean up
      sessionStorage.off("change", fn);
      window.sessionStorage.setItem("deliveryLocation", "false");
    };
  }, []);

  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    window.sessionStorage.setItem("deliveryLocation", open.toString());
    setState({ ...state, [anchor]: open });
  };

  const drawerContent = (anchor) => (
    <div
      style={{
        float: "left",
      }}
      className={clsx(classes.list, {
        [classes.fullList]: anchor === "top" || anchor === "bottom",
      })}
      role="presentation"
    >
      <StyledThemeProvider theme={StyledCostcoTheme}>
        <MuiThemeProvider theme={MuiCostcoTheme}>
          <SidePanel
            locale={locale}
            onUpdateDeliveryLocation={changeDeliveryLocation}
            onPanelClose={toggleDrawer(anchor, false)}
          />
        </MuiThemeProvider>
      </StyledThemeProvider>
    </div>
  );

  return (
    <>
      {["left"].map((anchor) => (
        <React.Fragment key={anchor}>
          <Header
            locale={locale}
            onChangeDeliveryLocation={toggleDrawer(anchor, true)}
            selectedZip={deliveryLocation.shipToLocation}
          />
          <Drawer
            anchor={anchor}
            className={classes.drawer}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            style={{ zIndex: '20012'}}
            classes={{ paper: classes.paper }}
          >
            {drawerContent(anchor)}
          </Drawer>
        </React.Fragment>
      ))}
    </>
  );
};

export default DeliveryLocation;
