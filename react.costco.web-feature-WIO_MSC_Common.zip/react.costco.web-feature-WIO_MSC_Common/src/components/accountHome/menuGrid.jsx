import React from "react"
import Grid from "@material-ui/core/Grid"
import styled from "styled-components"
import PropTypes from "prop-types"
import { useTranslation } from "react-i18next"
import {
  digitalMembershipCardUrl,
  bdAccountDetailsUrl,
  bdCommunicationPreferenceUrl,
  myOrdersUrl,
  accountDetailsUrl,
  businessDetailsUrl,
  renewMembershipUrl,
  addressBookUrl,
  paymentMethodsUrl,
  costcoPayurl,
  myListsUrl,
  communicationPreferenceUrl,
} from "../common/myAccount/accountLinks"
import {
  MembershipCard,
  Orders,
  AccountDetails,
  BusinessCenter,
  Renew,
  LocationSpecific,
  PaymentMethods,
  Lists,
  Settings,
  CostcoPay,
} from "forge-components/dist/icons"
import Text from 'forge-components/dist/components/Text'
import IconLabel from "../accountMenu/IconLabel"

const bdMenuList = [
  {
    id: 2,
    label: "Orders.label",
    icon: function() { return <Orders key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "Orders.description",
    link: myOrdersUrl,
  },

  {
    id: 3,
    label: "AccountDetails.label",
    icon: function() { return <AccountDetails key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "AccountDetails.description",
    link: bdAccountDetailsUrl,
  },
  {
    id: 4,
    label: "BusinessCenter.label",
    icon: function() { return <BusinessCenter key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "BusinessCenter.description",
    link: businessDetailsUrl,
  },
  {
    id: 5,
    label: "Renew.label",
    icon: function() { return <Renew key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "Renew.description",
    link: renewMembershipUrl,
  },
  {
    id: 6,
    label: "LocationSpecific.label",
    icon: function() { return <LocationSpecific key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "LocationSpecific.description",
    link: addressBookUrl,
  },
  {
    id: 7,
    label: "PaymentMethods.label",
    icon: function() { return <PaymentMethods key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "PaymentMethods.description",
    link: paymentMethodsUrl,
  },
  {
    id: 8,
    label: "CostcoPay.label",
    icon: function() { return <CostcoPay key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "CostcoPay.description",
    link: costcoPayurl,
  },
  {
    id: 9,
    label: "Lists.label",
    icon: function() { return <Lists key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "Lists.description",
    link: myListsUrl,
  },
  {
    id: 10,
    label: "Settings.label",
    icon: function() { return <Settings key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "Settings.description",
    link: bdCommunicationPreferenceUrl,
  },
  {
    id: 11,
    label: "MembershipCard.label",
    icon: function() { return <MembershipCard key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "MembershipCard.description",
    link: digitalMembershipCardUrl,
  },
]

const bcMenuList = [
  {
    id: 2,
    label: "Orders.list",
    icon: function() { return <Orders key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    link: myOrdersUrl,
    description:
      "Orders.description",
  },
  {
    id: 3,
    label: "AccountDetails.label",
    icon: function() { return <AccountDetails key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "AccountDetails.description",
  },
  {
    id: 6,
    label: "LocationSpecific.label",
    icon: function() { return <LocationSpecific key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "LocationSpecific.description",
  },
  {
    id: 7,
    label: "PaymentMethods.label",
    icon: function() { return <PaymentMethods key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "PaymentMethods.description",
  },
  {
    id: 9,
    label: "Lists.label",
    icon: function() { return <Lists key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description:
      "Lists.description",
  },
  {
    id: 10,
    label: "Settings.label",
    icon: function() { return <Settings key={`grid_${this.id}`} color="red.500" width={60} height={60} /> },
    description: "Settings.description",
  },
]

const menuGridConfig = {
  bc: bcMenuList,
  bd: bdMenuList,
}
const Styledlabel = styled(Text)`
  font-weight: bold;
  margin-bottom: 12px !important;
  margin-top: 12px !important;
`

const StyledGridItem = styled.div`
  height: 100%;
  text-align: center;
  border: 1px solid #dbdbdb;
  padding-left: 16px;
  padding-right: 16px;
  padding-bottom: 8px;
  :hover {
    border: 2px solid #909090 !important;
    ${Styledlabel} {
      text-decoration: underline;
    }
  }
`
const StyledGridDescription = styled.div`
  padding-top: 12px;
  padding-bottom: 16px;
`

const MenuGrid = ({ type }) => {
  const { t } = useTranslation()

  return (
    <Grid
      style={{ paddingLeft: 15, paddingBottom: 60 }}
      container
      spacing={4}
      alignItems="stretch"
    >
      {menuGridConfig[type].map(product => (
        <Grid
          key={`grid_${product.id}`}
          item
          xs={4}
          style={{ cursor: "pointer" }}
          onClick={() => (window.location.href = product.link)}
        >
          <StyledGridItem>
            <Styledlabel variant="t3">
              {t(product.label)}
            </Styledlabel>

            {product.icon()}

            <StyledGridDescription>
              <Text variant="t3">{t(product.description)}</Text>
            </StyledGridDescription>
          </StyledGridItem>
        </Grid>
      ))}
    </Grid>
  )
}
MenuGrid.propTypes = { type: PropTypes.oneOf(["bd", "bc"]) }

MenuGrid.defaultProps = { type: "bd" }

export default MenuGrid
