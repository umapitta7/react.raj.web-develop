import React from 'react';
import { render, screen } from '@testing-library/react';

import MenuGrid from './menuGrid';

describe('MenuGrid', () => {
  test('renders MenuItem component', () => {
    render(<MenuGrid />);
    // Jest is mocked to return the key for translations in setupTests.js
    screen.getByText('Orders.label');
    screen.getByText('Orders.description');
  });
});
