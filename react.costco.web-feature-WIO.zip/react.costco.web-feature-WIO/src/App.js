import React from 'react';

export default class App extends React.PureComponent {
  render() {
    return (
      <div>
        <div id="root1">test</div>
      </div>
    );
  }
}
