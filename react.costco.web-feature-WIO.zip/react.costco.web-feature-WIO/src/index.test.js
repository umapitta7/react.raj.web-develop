// TODO: Could test index.js to see if all of the providers are loaded and
// we have detected the correct locale.

describe('useLocation test', () => {
  it('Is Jest working', () => {
    expect(true).toEqual(true);
  });
});
