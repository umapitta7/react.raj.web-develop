import React from "react"
import { Col, Grid, Row } from "react-styled-flexboxgrid-v2"
import DeliveryLocationIcon from "forge-components/dist/components/Icon/svg-icons/BoxSolid.js"
import { useTranslation } from "react-i18next"
import "../index.css"
import MyWarehouseSelection from "../../MyWarehouse/components/myWarehouseSelection"

const Header = ({
  onChangeDeliveryLocation,
  selectedZip,
}) => {
  const { t } = useTranslation()

  return (
    <>
      <Row className={"delivery-location-wrapper"}>
        <Col xs={12} sm={12} lg={12} xl={12}>
          <Row className={"header-spacing"}>
            <MyWarehouseSelection />
            <Grid
              fluid
              className="header-padding"
              style={{
                marginLeft: "unset",
                marginRight: "unset",
                paddingLeft: "50px",
              }}
            >
              <Row>{t("deliveryLocation")}</Row>
              <Row className="header-spacing">
                <DeliveryLocationIcon className={"delivery-location-icon"} />
                {selectedZip ? (
                  <a
                    onClick={onChangeDeliveryLocation}
                    className={"header-link"}
                  >
                    {selectedZip}
                  </a>
                ) : (
                  <a
                    onClick={onChangeDeliveryLocation}
                    className={"header-link"}
                  >
                    {t("setDeliveryLocation")}
                  </a>
                )}
              </Row>
            </Grid>
          </Row>
        </Col>
      </Row>
    </>
  )
}

export default Header
