import PropTypes from 'prop-types';

export const SignOutShape = {
  ssoUrls: PropTypes.string,
  ssoEnabled: PropTypes.bool,
  isMobile: PropTypes.bool,
};
