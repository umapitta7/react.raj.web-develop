/* eslint-disable no-useless-constructor */
/* eslint-disable react/jsx-props-no-spreading */
import React, { PureComponent, Suspense } from 'react';
import '../../translations/language';
import OrderFilter from './ordersFilter';
import WarehousePurchases from './warehousePurchases';

class Index extends PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <Suspense fallback="">
          <OrderFilter style={{ width: '724px' }} />
          <WarehousePurchases width={724} height={900} />
        </Suspense>
      </div>
    );
  }
}

export default Index;
