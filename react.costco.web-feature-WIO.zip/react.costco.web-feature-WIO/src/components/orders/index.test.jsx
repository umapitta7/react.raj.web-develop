describe('Component test', () => {
  it('Jest works', () => {
    expect(true).toBeTruthy();
  });
});
