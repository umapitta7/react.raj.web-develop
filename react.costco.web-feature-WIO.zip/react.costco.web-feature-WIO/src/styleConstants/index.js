// import colors from './colors';
// import dimensions from './dimensions';
// import fonts from './fonts';
// import shadows from './shadows';
// import commonStyles from './commonStyles';
// import bannerStyles from './bannerStyles';

// export const styleConstants = {
//   colors,
//   dimensions,
//   fonts,
//   shadows,
//   bannerStyles,
//   commonStyles,
// };
